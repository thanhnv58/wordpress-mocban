jQuery( function( $ ) {
	'use strict';

	$( '#mobile' ).mmenu();
} );
