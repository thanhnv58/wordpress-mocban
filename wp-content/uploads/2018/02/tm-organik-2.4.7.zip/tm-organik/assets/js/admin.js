/*
 * Script for backend
 * Written By: Insight
 * */

// define insight
'use strict';

jQuery( document ).ready( function() {
	if ( jQuery().wpColorPicker ) {
		jQuery( '.insight-color-picker' ).wpColorPicker();
	}
} );
