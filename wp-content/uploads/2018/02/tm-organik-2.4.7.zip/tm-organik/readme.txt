=== TM Organik ===
Contributors: ThemeMove
Requires at least: WordPress 4.0
Tested up to: WordPress 4.9.4
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Tags: featured-images, post-formats, sticky-post, threaded-comments, translation-ready

== Description ==
We are glad to introduce to you TM Organik - the new released Woocommerce theme designed specially for fruits and vegetables sellers. This online shop template does not only obtain the high performance and effectiveness that an Woocommerce theme should have to attract customers. It’s better. Go exploring by yourself.

For more information about TM Organik please go to http://thememove.com.