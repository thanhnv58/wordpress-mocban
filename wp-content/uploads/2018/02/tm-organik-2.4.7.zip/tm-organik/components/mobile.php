<nav id="mobile">
	<?php Insight::menu_primary() ?>
</nav><!-- /#mobile -->
