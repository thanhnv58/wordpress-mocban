<div class="entry-footer">
	<?php Insight_Templates::entry_footer(); ?>
</div><!-- .entry-footer -->
